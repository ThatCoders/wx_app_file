const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const mimeTypes = require('mime-types');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));



const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});

const upload = multer({
  storage: storage
});

app.post('/upload', upload.single('file'), (req, res) => {
  const file = req.file;
  if (!file) {
    return res.send({
      success: false
    });
  }
  res.send({
    success: true,
    file: file
  });
});

app.get('/download/:filename', (req, res) => {
  const { filename } = req.params;
  const file = `${__dirname}/uploads/${filename}`;
  fs.stat(file, (err, stats) => {
    if (err) {
      console.error(err);
      return res.sendStatus(404);
    }
    res.setHeader('Content-Length', stats.size);
    res.setHeader('Content-Type', 'application/octet-stream');
    // res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
    fs.createReadStream(file).pipe(res);
  });
});

app.get('/filelist', (req, res) => {
  const baseDir = path.join(__dirname, 'uploads');
  let files = [];
  try {
    files = fs.readdirSync(baseDir);
  } catch (err) {
    console.log(`Error while reading directory: ${err}`);
    return res.status(500).send({
      success: false,
      error: 'Server error'
    });
  }
  const fileList = files.map((file) => {
    const filePath = path.join(baseDir, file);
    const stats = fs.statSync(filePath);
    return {
      name: file,
      type: mimeTypes.lookup(filePath),
      size: stats.size
    };
  });
  res.send({
    success: true,
    fileList: fileList
  });
});

const server = app.listen(52003, function() {
  const port = server.address().port;
  console.log(`File upload/download app listening at http://localhost:${port}`);
});

module.exports = app;
