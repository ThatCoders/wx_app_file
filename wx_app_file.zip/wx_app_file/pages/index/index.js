const app = getApp();

Page({
  data: {
    fileList: [],
  },

  onLoad() {
    this.loadFileList();
  },
  // 格式化文件名称
  formatName(name) {
    return name.length > 10 ? `${name.slice(0, 10)}..${name.slice(name.indexOf('.'))}` : name;
  },

  // 全局暂停/播放
  thatcoder() {
    console.log(app.globalData.globalAudio);
    if(typeof app.globalData.globalAudio.src != 'undefined'){
      if(app.globalData.globalAudioPaused == 0){
        console.log(app.globalData.globalAudio.src,'已连续播放');
        app.globalData.globalAudioPaused = 1;
        app.globalData.globalAudio.play()
      }else{
        console.log(app.globalData.globalAudio.src,'已暂停状态');
        app.globalData.globalAudioPaused = 0;
        app.globalData.globalAudio.pause()
      }
    }else{
      console.log('非播放状态');
    }
  },

  // 格式化文件大小
  formatSize(size) {
    let formattedSize = '';
    if (size < 1024) {
      formattedSize = `${size}B`;
    } else if (size < 1024 * 1024) {
      formattedSize = `${(size / 1024).toFixed(2)}KB`;
    } else if (size < 1024 * 1024 * 1024) {
      formattedSize = `${(size / 1024 / 1024).toFixed(2)}MB`;
    } else {
      formattedSize = `${(size / 1024 / 1024 / 1024).toFixed(2)}GB`;
    }
    return formattedSize;
  },

  // 格式化文件类型
  formatType(type) {
    let formattedType = '';
    let icon = '';
    if (type.startsWith('image')) {
      formattedType = '📷️';
      icon = 'photo-o';
    } else if (type.startsWith('video')) {
      formattedType = '🎞️';
      icon = 'video-o';
    } else if (type.startsWith('audio')) {
      formattedType = '🎵';
      icon = 'service-o';
    } else {
      formattedType = '❓️';
      icon = 'warn-o';
    }
    return {formattedType:formattedType,icon:icon};
  },

  // 加载文件列表
  loadFileList() {
    wx.request({
      url: `${app.globalData.serverUrl}/filelist`,
      success: (res) => {
        const { fileList } = res.data;
        fileList.forEach((file) => {
          file.size = this.formatSize(file.size);
          const typeAndIcon = this.formatType(file.type.toString());
          file.type = typeAndIcon.formattedType;
          file.icon = typeAndIcon.icon;
          file.nick = this.formatName(file.name);
          // file.name = this.formatName(file.name)
        });
        this.setData({ fileList });
      },
      fail: (err) => {
        console.error('Failed to load file list:', err);
      }
    });
  },

  // 上传文件
  handleUpload() {
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      success: (res) => {
        this.uploadFile(res.tempFiles);
      },
      fail: (err) => {
        console.error('Failed to choose message file:', err);
      }
    });
  },

  // 上传文件到服务端
  uploadFile(tempFiles) {
    wx.showLoading({ title: '上传中...', mask: true });
    wx.uploadFile({
      url: `${app.globalData.serverUrl}/upload`,
      filePath: tempFiles[0].path,
      name: 'file',
      success: (res) => {
        wx.hideLoading();
        const { success } = JSON.parse(res.data);
        if (success) {
          this.loadFileList();
          wx.showToast({
            title: '上传成功',
            icon: 'success',
            duration: 1000
          });
        } else {
          wx.showToast({
            title: '上传失败',
            icon: 'none',
            duration: 1000
          });
        }
      },
      fail: (err) => {
        wx.hideLoading();
        wx.showToast({
          title: '上传失败',
          icon: 'none',
          duration: 1000
        });
        console.error('Failed to upload file:', err);
      }
    });
  },

  // 选择文件
  handleChooseFile() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image', 'video'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath;
        wx.showLoading({
          title: '正在上传...',
        });
        wx.uploadFile({
          url: `${app.globalData.serverUrl}/upload`,
          filePath: tempFilePath,
          name: 'file',
          success: (res) => {
            const { success } = JSON.parse(res.data);
            wx.hideLoading();
            if (success) {
              this.setData({
                fileList: [],
                page: 1
              }, () => {
                this.loadFileList();
              });
              wx.showToast({
                title: '上传成功',
                icon: 'success',
                duration: 2000
              });
            } else {
              wx.showToast({
                title: '上传失败',
                icon: 'none',
                duration: 2000
              });
            }
          },
          fail: (err) => {
            wx.hideLoading();
            wx.showToast({
              title: '上传失败',
              icon: 'none',
              duration: 2000
            });
            console.error('Failed to upload file:', err);
          }
        });
      }
    });
  },

  // 根据文件类型执行不同的操作
  handleFileAction(e) {
    const { filename, type } = e.currentTarget.dataset;
    wx.showLoading({ title: '下载中...', mask: true });
    wx.downloadFile({
      url: `${app.globalData.serverUrl}/download/${filename}`,
      success:(res) => {
        wx.hideLoading();
        switch (type) {
          case '❓️':
            wx.showToast({
              title: '不支持的文件类型',
              icon: 'none',
              duration: 2000
            });
            break;
          case '📷️':
            wx.previewImage({
              urls: [res.tempFilePath],
              current: res.tempFilePath
            });
            break;
          case '🎞️':
            wx.navigateTo({
              url: `/pages/video-preview/video-preview?url=${encodeURIComponent(res.tempFilePath)}`
            });
            break;
          case '🎵':
            app.globalData.globalAudio.src = res.tempFilePath;
            app.globalData.globalAudioPaused = 0;
            this.thatcoder();
            console.log('新全局audio对象播放中');
            break;
        }
      },
      fail(err) {
        wx.hideLoading();
        wx.showToast({
          title: '下载失败',
          icon: 'none',
          duration: 2000
        });
        console.error('Failed to download file:', err);
      }
    });
  }
});

